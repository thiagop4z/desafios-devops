# Solução

Além dos requitos principais e extras, foi incluída na solução uma variável para coleta do nome da *Key Pair* do usuário, possibilitando assim a conexão via SSH sem a necessidade de edição do cógido ou acesso ao console da *cloud* para configuração da *Key Pair* na instância.

A documentação oficial do *Terraform* foi utilizada para consulta durante o desenvolvimento da solução.

Thiago Paz.
